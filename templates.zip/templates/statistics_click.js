// 휴대폰 모델별 VOC 건수 클릭 이벤트
function addModelClickEvents() {
    const modelTableBody = document.getElementById('modelTableBody');
    if (modelTableBody) {
        const rows = modelTableBody.querySelectorAll('tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 3) {
                const countCell = cells[2]; // VOC 건수 셀
                const modelName = cells[1].textContent.trim();
                const count = countCell.textContent.trim();
                
                // 클릭 이벤트 추가
                countCell.style.cursor = 'pointer';
                countCell.style.textDecoration = 'underline';
                countCell.style.color = '#667eea';
                countCell.addEventListener('click', function() {
                    window.open(`http://127.0.0.1:5001/voc/model/${encodeURIComponent(modelName)}`, '_blank');
                });
            }
        });
    }
}

// 월별 VOC 건수 클릭 이벤트
function addMonthlyClickEvents() {
    const monthlyChart = document.getElementById('monthlyChart');
    if (monthlyChart && charts.monthly) {
        monthlyChart.onclick = function(evt) {
            const points = charts.monthly.getElementsAtEventForMode(evt, 'nearest', { intersect: true }, true);
            
            if (points.length) {
                const firstPoint = points[0];
                const label = charts.monthly.data.labels[firstPoint.index];
                const month = label;
                
                // 월별 VOC 목록 페이지로 이동
                window.open(`http://127.0.0.1:5001/voc/monthly/${month}`, '_blank');
            }
        };
    }
}

// 페이지 로드 시 이벤트 추가
document.addEventListener('DOMContentLoaded', function() {
    // 모델별 통계 로드 후 클릭 이벤트 추가
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                addModelClickEvents();
                addMonthlyClickEvents();
            }
        });
    });
    
    // 테이블이 표시되면 클릭 이벤트 추가
    const modelTable = document.getElementById('modelTable');
    if (modelTable) {
        observer.observe(modelTable, { childList: true, subtree: true });
    }
    
    // 월별 차트가 로드되면 클릭 이벤트 추가
    const monthlyChart = document.getElementById('monthlyChart');
    if (monthlyChart) {
        observer.observe(monthlyChart, { childList: true, subtree: true });
    }
});

// 기존 loadModelStatistics 함수 오버라이드
const originalLoadModelStatistics = loadModelStatistics;
loadModelStatistics = async function(queryString) {
    await originalLoadModelStatistics(queryString);
    addModelClickEvents();
};

// 기존 loadMonthlyStatistics 함수 오버라이드
const originalLoadMonthlyStatistics = loadMonthlyStatistics;
loadMonthlyStatistics = async function() {
    await originalLoadMonthlyStatistics();
    addMonthlyClickEvents();
};
